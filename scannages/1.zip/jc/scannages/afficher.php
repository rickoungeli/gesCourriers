<?php

include("classes/services.class.inc.php");
$service = new service;
$service->afficher();

?>
